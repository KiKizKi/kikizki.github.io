﻿using System;
using System.Data;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.Windows.Input;


namespace DatabaseConnection
{	
	public class StartUPtext
	{
		static int delay0 = 0;

		//String to hold text that's about to be written to the console
		static string text = "";
		static string Version = "V:1.0.3";


		private static void Text ()
		{		

			Console.ForegroundColor = ConsoleColor.Red;	
			Console.SetCursorPosition(0,0);
			Console.Write ("#####################################");
			Console.SetCursorPosition(0,1);

			Console.Write ("#######"); Console.ForegroundColor = ConsoleColor.Cyan;
			Console.Write("  Console Application  ");
			Console.ForegroundColor = ConsoleColor.Red; Console.Write("#######");
			Console.SetCursorPosition(0,2);

			Console.Write ("#####");   Console.ForegroundColor = ConsoleColor.Cyan; 
			Console.Write("  Retrieves Metadata From  ");
			Console.ForegroundColor = ConsoleColor.Red; Console.Write("#####");

			Console.SetCursorPosition(0,3);
			Console.Write ("####");   Console.ForegroundColor = ConsoleColor.Cyan;  
			Console.Write("  FireBird or SQL Databases   ");
			Console.ForegroundColor = ConsoleColor.Red; Console.Write("###");

			Console.SetCursorPosition(0,4);
			Console.Write ("######");
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write("  Windows edit.  "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write(Version + " "); 
			Console.ForegroundColor = ConsoleColor.Red; Console.Write("######                            ");

			Console.SetCursorPosition(0,5);
			Console.ForegroundColor = ConsoleColor.Red; Console.Write ("#####################################"); 
			Console.ForegroundColor = ConsoleColor.DarkGray;

			Console.ForegroundColor = ConsoleColor.White; Console.Write ("");

			Thread.Sleep(delay0);
			Console.SetCursorPosition(40,2);
			text = "Link to the GitHub Page";	for (int x = 0; x < 23;x++)	{ Console.ForegroundColor = ConsoleColor.Gray; if(x > 11 && x<18 ){Console.ForegroundColor = ConsoleColor.DarkYellow;} Console.Write (text[x]); }

			Console.ForegroundColor = ConsoleColor.White;
			Thread.Sleep(delay0);
			Console.SetCursorPosition(40,3);
			Console.Write ("https://github.com/KiKizKi/kikizki.github.io");

			Console.SetCursorPosition(0,7);
			Thread.Sleep(1000);
		}

		private static void startText ()
		{		

			try {				
				Text ();
			} catch (Exception ex) {
				Console.WriteLine (ex);
			}
		}

		public static void Startup()
		{
			int i = 0;

			//Stops crashing if user inputs while startText is running
			do
			{
				startText ();
				i = 1;
			}
			while (i != 1);
		}
	}
}