﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;
using System.Globalization;


namespace DatabaseConnection
{
	public class SQLDB
	{
		//Integers
		static int i = 0;
		static int o = 0;
		static int p = 0;
		static int h = 0;


		//Strings
		static string ServerIP = "";

		static string UserID = "";
		static string Password = "";
		static string pathToFile = "";
		static string Path = "";
		static string filename = "";
		static string File = "";
		static string ConnectionString = "";
		static string CSChoice = "";
		static string FileFormat = "";


		//Lists to save the data into
		static List<string> TABLENAMES = new List<string> ();
		static List<string> COLUMNNAMES = new List<string> ();
		static List<string> COLUMNTYPES = new List<string> ();
		static List<string> DATABASENAMES = new List<string> ();


		static string Databasename = "";
		static List <string> DBlist = new List<string> ();
		static List <string> DBnamelist = new List<string> ();


		//A piece of code which, autofills the closest name of entered, when pressign TAB
		//Inserts DB name to a list when pressing INSERT, and removes the last item in list with DELETE
		public static void AutoFill_InputDBNames()
		{
			string Insert = "";

			int tab = -1;

			var builder = new StringBuilder ();
			var input = Console.ReadKey (intercept: true);
			var match = "";
			var Line = 0;

			while (input.Key != ConsoleKey.Enter) {
				Line = Console.CursorTop;
				Console.SetCursorPosition (0, (Line - 3));
				Console.Write ("Current items: " + Databasename);
				Console.SetCursorPosition (0, Line);

				var currentInput = builder.ToString ();

				if (input.Key == ConsoleKey.Tab) {

					match = DBlist.FirstOrDefault (item => item != currentInput && item.StartsWith (currentInput, true, CultureInfo.InvariantCulture));
				
					if (string.IsNullOrEmpty (match)) {
						input = Console.ReadKey (intercept: true);
						continue;
					}
					currentInput = builder.ToString ();
					ClearCurrentLine ();
					builder.Clear ();

					Console.Write (match);
					builder.Append (match);
				} 
				if (input.Key == ConsoleKey.UpArrow) {
					if (tab <= 0) {
						tab = DBlist.Count ();
					}	
					tab--;
					currentInput = builder.ToString ();
					match = DBlist [tab].ToString ();

					ClearCurrentLine ();
					builder.Clear ();

					Console.Write (match);
					builder.Append (match);
				}
				if (input.Key == ConsoleKey.DownArrow) {
					if (tab >= DBlist.Count () - 1) {
						tab = 0;
					}
					tab++;
					currentInput = builder.ToString ();
					match = DBlist [tab].ToString ();

					ClearCurrentLine ();
					builder.Clear ();

					Console.Write (match);
					builder.Append (match);
				}
				if (input.Key == ConsoleKey.Insert) {
					Insert = Insert + match.ToString () + " ";
					Console.SetCursorPosition (15, (Line - 3));
					Console.Write (Insert);
					Console.SetCursorPosition (0, Line);
					DBnamelist.Add (match.ToString ());
					DATABASENAMES.Add (match);
				}
				if (input.Key == ConsoleKey.Delete && DBnamelist.Count () > 0) {
					DBnamelist.RemoveAt (DBnamelist.Count () - 1);
					DATABASENAMES.RemoveAt (DATABASENAMES.Count () - 1);
					for (int m = 0; m < DBnamelist.Count (); m++) {
						Databasename = Databasename + DBnamelist [m].ToString () + " ";
					}

					if (DBnamelist.Count () == 0) {
						Databasename = "";
						DBnamelist.Clear ();
					}
					Insert = "";
					Console.SetCursorPosition (15, (Line - 3));
					Console.Write (new String (' ', Console.BufferWidth - 16));
					Console.SetCursorPosition (15, (Line - 3));
					Console.Write (Databasename);
					Console.SetCursorPosition (0, Line);
					Databasename = "";
				}


				else {
					if (input.Key == ConsoleKey.Backspace && currentInput.Length > 0) {
						builder.Remove (builder.Length - 1, 1);
						ClearCurrentLine ();
						currentInput = currentInput.Remove (currentInput.Length - 1);
						Console.Write (currentInput);
					} else {
						var key2 = input.KeyChar;
						builder.Append (key2);
						Console.Write (key2);
					}
				}
				input = Console.ReadKey (intercept: true);			
				Console.Write (input.KeyChar);

			}
		}


		//Piece of code which clears the current line, and goes back to the original line
		private static void ClearCurrentLine()
		{
			var currentLine = Console.CursorTop;
			Console.SetCursorPosition(0, Console.CursorTop);
			Console.Write(new string(' ', Console.WindowWidth));
			Console.SetCursorPosition(0, currentLine);
		}




		private static void ConnectionStringChoice ()
		{

			//Asks user to input a connectionstring, or to leave empty, and ask the user the required information
			Console.WriteLine("");
			Console.Write ("Enter connectionstring here, or leave empty to manually create one:\nEg: User ID = sa; Password = 1234; Server = 192.168.0.0;\n");
			CSChoice = Console.ReadLine();
			//CSChoice = "User ID = sa;Password = agripomo;Server = 192.168.0.8;";

			//If CSChoice IS NOT empty, connectionstring = the string, user input
			if(CSChoice != "")
			{
				ConnectionString = CSChoice;
			}

			//If CSChoice IS empty, start asking the user for required information
			if (CSChoice == "") {

				Connectionstring ("");
			}
		}

		private static void Connectionstring(string connectionstring)
		{			
			if (connectionstring.Count () < 2) {
				//Asks the user for Server IP, User ID, Password ( Which is typed hidden from view )
				Console.Write ("Enter Server IP: ");
				ServerIP = Console.ReadLine ();


				Console.Write ("Enter User ID: ");
				UserID = Console.ReadLine ();

				Console.Write ("Enter User Password: ");
				ConsoleKeyInfo key;
				do {
					key = Console.ReadKey (true);

					if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter) {
						Password += key.KeyChar;
						Console.Write ("*");
					} else {
						if (key.Key == ConsoleKey.Backspace && Password.Length > 0) {
							Password = Password.Substring (0, (Password.Length - 1));
							Console.Write ("\b \b");
						}
					}
				} while (key.Key != ConsoleKey.Enter);

				ConnectionString = "User ID = " + UserID + "; Password = " + Password + "; Server = " + ServerIP + ";";
			} else {	
				ConnectionString = connectionstring;

			}
		}


		private static void DataBaseNames ()
		{


			//Opens a db connection to seek database names for user to choose from
			SqlConnection Databases = new SqlConnection (ConnectionString);
			Databases.Open ();

			Console.WriteLine ("");
			Console.WriteLine ("Found Databases: ");

			SqlCommand DBNames = new SqlCommand ("SELECT name from sys.sysdatabases WHERE HAS_DBACCESS(name) = 1", Databases);
			SqlDataReader DBreader = DBNames.ExecuteReader ();
			while (DBreader.Read ()) {				
				Console.WriteLine (DBreader ["name"].ToString ());
				DBlist.Add (DBreader ["name"].ToString ());

			}
			//closes the db connection
			Databases.Close ();		

			//Gets the wanted databases from user
			Console.WriteLine ();
			Console.WriteLine ();
			Console.WriteLine ();
			Console.Write ("Enter DB name(s), [arrows up/down] [Insert/Delete]\n[TAB] to autofill, [Enter] to continue");
			Console.WriteLine ();

			AutoFill_InputDBNames ();
		
			Console.Clear ();
			//Writes the amount of found databases
			Console.WriteLine("Found " +DATABASENAMES.Count().ToString() + " Databases with provided names");

		}

		private static void TryFilePath (string path)
		{
			Path = path;				
			if (path.Count () < 2) {
				//Tries to write a empty file to the defined path, then removes it
				Console.Write ("Enter a path for the file (C:\\User\\Documents): ");
				pathToFile = Console.ReadLine ();
				pathToFile = pathToFile + "/";


				string TryFile = " ";
				string TryPath = "";

				//Name & type for the temporary file
				TryPath = pathToFile + "TEMPWRITEtest.txt";
				System.IO.File.WriteAllText (TryPath, TryFile);

				//Deleting the file
				System.IO.File.Delete (TryPath);
			} else {
				pathToFile = path + "/";
			}
		}

		private static void FileName (string Name)
		{
			if (Name == "") {
				//Asks the user for the filename & type
				Console.Write ("Enter a name and file type for the file. Example (File.csv): ");
				filename = Console.ReadLine ();


				//Adds them to the path
				pathToFile = pathToFile + filename;
			} else {
				filename = Name;
				pathToFile = pathToFile + filename;
			}

			char Delimiter = '.';
			string[] Filenames = filename.Split (Delimiter);
			FileFormat = Filenames [1];
		}








		private static void MultiFileCreateFile(string CS, string MultiFile, string Dates)
		{		
			try{

			string date = "";
			//V1.0.3 Continue
			if (Dates == "True") {
				 date = DateTime.Today.ToString ("dd-MM-yy", CultureInfo.InvariantCulture);

				char Delimiter = '.';
				string[] Filenames = filename.Split (Delimiter);

				filename = Filenames [0] + "_" + date + "." + FileFormat;
			}

			if (MultiFile == "True") {



				//adds columns: Database, Table, Column, Datatype, to the file
				File = "Database" + "," + "Table" + "," + "Column" + "," + "Datatype" + Environment.NewLine;

				for (int z = 0; z < DATABASENAMES.Count(); z++) {
							
						if (Dates == "True") {
							
							date = DateTime.Today.ToString ("dd-MM-yy", CultureInfo.InvariantCulture);
							filename = DATABASENAMES[z] + "_" + date + "." + FileFormat;

						}else
						{							
						filename = DATABASENAMES[z];
						}

						Console.Write(DATABASENAMES [z]);

						if (CS.Count () < 2) {
							//Adds the databasename to the connectionstring
							if (CSChoice != "") {
								ConnectionString = CSChoice + "Database = '" + DATABASENAMES [h] + "';";
							}

							//Adds the databasename to the connectionstring
							if (CSChoice == "") {
								ConnectionString = "User ID = " + UserID + "; Password = " + Password + "; Database = " + DATABASENAMES [h] + "; Server = " + ServerIP + ";";
							}
						} else {
							ConnectionString = CS + " Database = " + DATABASENAMES [h];
						}
						//2 Connections to the database, for 2 different DataReaders
						SqlConnection DBConnection = new SqlConnection (ConnectionString);
						SqlConnection DBConnection2 = new SqlConnection (ConnectionString);

						//Starting connection(s) to the server
						DBConnection2.Open ();
						DBConnection.Open ();								

						//SQL command, Chooses the table names from sys.Tables
						SqlCommand cmd = new SqlCommand ("SELECT name FROM sys.Tables", DBConnection);

						//SQL Reader, uses the SQL command "cmd"
						System.Data.SqlClient.SqlDataReader reader = cmd.ExecuteReader ();

						//when the reader finds something to read, adds the tables name to a table list and closes the reader
						while (reader.Read ()) {					
							TABLENAMES.Add (reader ["name"].ToString ());
						}
						reader.Close ();

						//Null "i", used for TABLENAMES list
						i = 0;

						//for each found table, adds columns & datatypes for the table
					
					

							for (o = 0; o < TABLENAMES.Count (); o++) {
							try{						
								
								//Shows the user the current databasename, and progress of going through them
								Console.Title = DATABASENAMES [h] + "  " + (h + 1).ToString () + "/" + DATABASENAMES.Count ().ToString ();

								//SQL command, Chooses the column names based on the table name
								SqlCommand cmd2 = new SqlCommand ("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS " +
									"WHERE TABLE_NAME = '" +TABLENAMES[o] + "'",DBConnection);
							
								//Null "p", used for COLUMNNAMES list
								p = 0;
						
								//Starts "reader2", while it reads, adds column names to a column list and column types to a column list           
					
								System.Data.SqlClient.SqlDataReader reader2 = cmd2.ExecuteReader (CommandBehavior.KeyInfo);

							

								while(reader2.Read()){
									COLUMNNAMES.Add (reader2["COLUMN_NAME"].ToString ());						
									COLUMNTYPES.Add (reader2["DATA_TYPE"].ToString ());		
									File = File + DATABASENAMES [h] + "," + TABLENAMES [i] + "," + COLUMNNAMES [p] + "," + COLUMNTYPES [p] + Environment.NewLine;

									//increments "p" by 1 with every loop
									p++;
								}						

									reader2.Close();

										

							}catch(Exception e){
								Console.WriteLine(e);
							}
								//Writes the current state of going through the tables to console 
								Console.Write ("\r{0}" + "/" + TABLENAMES.Count ().ToString (), i);

								//Clears the lists, for the next Tables' ones
								COLUMNNAMES.Clear ();
								COLUMNTYPES.Clear ();
								

								//null "p" and increment "i" in order to move to the next table
								p = 0;
								i++;
							}

						

						File = File + Environment.NewLine;

						//Clears the console line
						Console.Write ("\r              ");

						//Closes connections and clears the tablename list, for the next ones
						reader.Close ();
						DBConnection.Close ();
						DBConnection2.Close ();	
						TABLENAMES.Clear ();										

						//Null integers & increment "h" with 1, H is used for DATABASENAMES list
						i = 0;
						p = 0;
						h++;

					MultiFileFinishingFile();

					}


					h = 0;

					Console.Clear();
					//creates a file from created lists
					Console.WriteLine ("Search complete!");
					Console.WriteLine ("Created a file to: " + Path);
					Console.WriteLine ("");	

				System.Environment.Exit (0);
			}else{
				CreateFile (CS,Dates);
			}
			}catch(Exception e) {
				Console.Write (e);
			}

		}



		private static void CreateFile (string CS,string Dates)
		{


			if (Dates == "True") {
				string date = DateTime.Today.ToString ("dd-MM-yy", CultureInfo.InvariantCulture);

				char Delimiter = '.';
				string[] Filenames = filename.Split (Delimiter);

				filename = Filenames [0] + "_" + date + "." + FileFormat;
			}

				//adds columns: Database, Table, Column, Datatype, to the file
				File = "Database" + "," + "Table" + "," + "Column" + "," + "Datatype" + Environment.NewLine;

				//For each found databasename, in the databaselist, the user filled
				for (int g = 0; g < DATABASENAMES.Count (); g++) {	
					Console.Write (DATABASENAMES [g]);
					if (CS.Count () < 2) {
						//Adds the databasename to the connectionstring
						if (CSChoice != "") {
							ConnectionString = CSChoice + "Database = '" + DATABASENAMES [h] + "';";
						}

						//Adds the databasename to the connectionstring
						if (CSChoice == "") {
							ConnectionString = "User ID = " + UserID + "; Password = " + Password + "; Database = " + DATABASENAMES [h] + "; Server = " + ServerIP + ";";
						}
					} else {
						ConnectionString = CS + " Database = " + DATABASENAMES [h];
					}
					//2 Connections to the database, for 2 different DataReaders
					SqlConnection DBConnection = new SqlConnection (ConnectionString);
					SqlConnection DBConnection2 = new SqlConnection (ConnectionString);

					//Starting connection(s) to the server
					DBConnection2.Open ();
					DBConnection.Open ();								

					//SQL command, Chooses the table names from sys.Tables
					SqlCommand cmd = new SqlCommand ("SELECT name FROM sys.Tables", DBConnection);

					//SQL Reader, uses the SQL command "cmd"
					System.Data.SqlClient.SqlDataReader reader = cmd.ExecuteReader ();

					//when the reader finds something to read, adds the tables name to a table list and closes the reader
					while (reader.Read ()) {					
						TABLENAMES.Add (reader ["name"].ToString ());
					}
					reader.Close ();

					//Null "i", used for TABLENAMES list
					i = 0;

					//for each found table, adds columns & datatypes for the table
					try {
						for (o = 0; o < TABLENAMES.Count (); o++) {

						//Shows the user the current databasename, and progress of going through them
						Console.Title = DATABASENAMES [h] + "  " + (h + 1).ToString () + "/" + DATABASENAMES.Count ().ToString ();

						//SQL command, Chooses the column names based on the table name
						SqlCommand cmd2 = new SqlCommand ("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS " +
							"WHERE TABLE_NAME = '" +TABLENAMES[o] + "'",DBConnection);

						//Null "p", used for COLUMNNAMES list
						p = 0;

						//Starts "reader2", while it reads, adds column names to a column list and column types to a column list           

						System.Data.SqlClient.SqlDataReader reader2 = cmd2.ExecuteReader (CommandBehavior.KeyInfo);



						while(reader2.Read()){
							COLUMNNAMES.Add (reader2["COLUMN_NAME"].ToString ());						
							COLUMNTYPES.Add (reader2["DATA_TYPE"].ToString ());		
							File = File + DATABASENAMES [h] + "," + TABLENAMES [i] + "," + COLUMNNAMES [p] + "," + COLUMNTYPES [p] + Environment.NewLine;

							//increments "p" by 1 with every loop
							p++;
						}

						reader2.Close();

							
							//Writes the current state of going through the tables to console 
							Console.Write ("\r{0}" + "/" + TABLENAMES.Count ().ToString (), i);

							//Clears the lists, for the next Tables' ones
							COLUMNNAMES.Clear ();
							COLUMNTYPES.Clear ();
							

							//null "p" and increment "i" in order to move to the next table
							p = 0;
							i++;
						}

					} catch (Exception e) {
						Console.WriteLine (e);
					}

					File = File + Environment.NewLine;

					//Clears the console line
					Console.Write ("\r              ");

					//Closes connections and clears the tablename list, for the next ones
					reader.Close ();
					DBConnection.Close ();
					DBConnection2.Close ();	
					TABLENAMES.Clear ();										

					//Null integers & increment "h" with 1, H is used for DATABASENAMES list
					i = 0;
					p = 0;
					h++;
				}
			}


		private static void MultiFileFinishingFile()
		{		
			string finishedPath = Path;

			finishedPath = Path + filename;
			System.IO.File.WriteAllText (finishedPath,File);
			finishedPath = "";
			filename = "";

		}
		private static void FinishingFile()
		{
			Console.Clear();
			//creates a file from created lists
			System.IO.File.WriteAllText (pathToFile, File);
			Console.WriteLine ("Search complete!");
			Console.WriteLine ("Created a file to: " + pathToFile);
			Console.WriteLine ("");
			Console.CursorVisible = true;
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write ("Open the file? [y] yes, any other key to exit: ");
			string Valinta = Console.ReadLine ();
			if (Valinta == "y") {
				//Opens the file if user entered [Y]
				Process.Start (pathToFile);			
				System.Environment.Exit (0);
			}
		}

		private static void Cleanup()
		{
			//Clear all the used strings, integers, connections etc.
			ServerIP = "";
			Databasename = "";
			UserID = "";
			Password = "";
			pathToFile = "";
			filename = "";
			File = "";
			ConnectionString = "";

			TABLENAMES.Clear();
			COLUMNNAMES.Clear();
			COLUMNTYPES.Clear();

			i=0;
			p=0;
			h=0;
			o=0;

			System.Environment.Exit (0);
		}

		//Normal side of SQL
		private static void SQLdb()
		{
			try {
				
				try{
					
					TryFilePath("");

				}catch (Exception)
				{
					Console.WriteLine("Path not available, check for typos or choose another location");
					Console.WriteLine();
					pathToFile = "";
					SQLdb();
				}

				FileName("");

				ConnectionStringChoice();

				DataBaseNames();

			}catch (Exception e) {
				ServerIP = "";
				Databasename = "";
				UserID = "";
				Password = "";
				pathToFile = "";
				filename = "";


				Console.Clear ();
				Console.WriteLine ("Error and it's details: "+e);
				Console.WriteLine ("Something went wrong, Try again");
				SQLdb ();

			}

			try{
				
				Console.WriteLine (" ");
				Console.WriteLine (" ");

				//starts a spinner loading animation to check progress
				var spinner = new Spinner (8, 5);
				Console.CursorVisible = false;
				spinner.Start ();

				Console.ForegroundColor = ConsoleColor.Green;
				Console.Write ("Fetching data");
				Console.WriteLine("");
				Console.WriteLine("Current / Tables");

				CreateFile ("","");		
				spinner.Stop ();
				FinishingFile ();
				Cleanup ();

			}catch (Exception e ) {
				Console.WriteLine (e);
			}
		}


		//Config side of the SQL part
		private static void SQLdbconfig(List<string> db,string UsePath, string UseFilename, string UseConnectionString, string UseDatabasenames,string MultiFile,string Dates)
		{
			
			try {

				try{
					//If path name, entered in config file, length is less than 1, asks the user for the path, otherwise uses the path found in config
					//If path in config file is wrong, will make it empty, and ask for it from the user
					if(UsePath.Count() < 1)
					{
						TryFilePath("");
					}else{
						TryFilePath(UsePath);
					}

				}catch (Exception)
				{
					Console.WriteLine("Path not available, check for typos or choose another location");
					Console.WriteLine();

					SQLdbconfig(db,UsePath,UseFilename,UseConnectionString,UseDatabasenames,MultiFile,Dates);
				}

				//If file name, entered in config file, length is less than 1, asks the user for a name for the file, otherwise uses the name found in the config
				if(UseFilename.Count()<1)
				{
					FileName("");
				}else{
					FileName(UseFilename);
				}

				//If Connection string, entered in config file, length is less than 1, asks the user for a connection string, otherwise uses the CS found in config
				if(UseConnectionString.Count()<1)
				{
					Connectionstring("");				
				}else{		
					Connectionstring(UseConnectionString);
				}		

				//If DB count is less than 1, ask user for DB names
				if(db.Count()<1)
				{
				DataBaseNames();
				}
				else {
					for(int i = 0; i <db.Count();i++){
						DATABASENAMES.Add(db[i]);
					}
				}

				Console.Clear();

			}catch (Exception) {
				ServerIP = "";
				Databasename = "";
				UserID = "";
				Password = "";
				pathToFile = "";
				filename = "";


				Console.Clear ();
				Console.WriteLine ("Something went wrong, Try again, Config will be disabled for now");

				SQLdb ();

			}

			try{

				Console.WriteLine (" ");
				Console.WriteLine (" ");

				Console.ForegroundColor = ConsoleColor.Green;
				Console.Write ("Fetching data");
				Console.WriteLine("");
				Console.WriteLine("Current / Tables");

				if(MultiFile == "True")
				{
					var spinner = new Spinner (8, 5);
					Console.CursorVisible = false;
					spinner.Start ();
					try{
						
					MultiFileCreateFile(ConnectionString,MultiFile,Dates);
					}catch(Exception){
						
					}

					spinner.Stop ();

				}else
				{				
					var spinner = new Spinner (8, 5);
					Console.CursorVisible = false;
					spinner.Start ();
				
					CreateFile (ConnectionString,Dates);	

				spinner.Stop ();
				FinishingFile ();
			}

				Cleanup ();

			}catch (Exception e ) {
				Console.WriteLine (e);
			}
		}

		//Normal side of SQL
		public static void SQL()
		{			
				SQLdb ();
		}
	
		//Config side of SQL
		public static void SQLconfig(List<string> db,string UsePath, string UseFilename, string UseConnectionString, string UseDatabasenames, string MultiFile,string Dates)
		{								
			SQLdbconfig (db,UsePath,UseFilename,UseConnectionString,UseDatabasenames, MultiFile, Dates);	
		}
	}
}