﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Globalization;
using FirebirdSql.Data.FirebirdClient;
using FirebirdSql;
using FirebirdSql.Data;
using System.Windows.Forms;


namespace DatabaseConnection
{

	public class FireBirdDB
	{
		//Integers
		static int i = 0;
		static int o = 0;
		static int p = 0;
		static int j = 0;

		//strings
		static string FB_Connectionstring = "";
		static string FB_UserID="";
		static string FB_Password ="";
		static string FB_Database = "";
		static string FB_Datasource = "";
		static string FB_Port = "";
		static string FB_File = "";
		static string FB_CSChoice = "";
		static string FB_PathToFile="";
		static string FB_FileName = "";
		static string FB_FileFormat = "";
		static string FB_Path = "";


		//Lists to save the data into
		static List<string> FBTABLENAMES = new List<string> ();
		static List<string> FBCOLUMNNAMES = new List<string> ();
		static List<string> FBCOLUMNTYPES = new List<string> ();


		private static void FBConnectionstringChoice()
		{
			//Asks user to input a connectionstring, or to leave empty, and ask the user the required information
			Console.WriteLine ("");
			Console.Write ("Enter connectionstring here, or leave empty to manually create one:\nEg. User ID=sysdba;Password=password;Database=:x:\\F\\F\\Db.fdb;DataSource=192.168.0.0;\n");
			FB_CSChoice = Console.ReadLine();

			//If CSChoice IS NOT empty, connectionstring = the string, user input
			if (FB_CSChoice != "")
			{
				FB_Connectionstring = FB_CSChoice;
			}

			//If CSChoice IS empty, start asking the user for required information
			if (FB_CSChoice == "")
			{
				FBConnectionstring ("");
			}

		}

		private static void FBConnectionstring(string connectionstring)
		{		
			if (connectionstring.Count () < 2) {
				//Asks the user for Server IP, User ID, Password ( Which is typed hidden from view )
				Console.Write ("Enter Server IP: ");
				FB_Datasource = Console.ReadLine ();
				Console.Write ("Enter User ID: ");
				FB_UserID = Console.ReadLine ();
				Console.Write ("Enter User Password: ");
				ConsoleKeyInfo key;
				do {
					key = Console.ReadKey (true);

					if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter) {
						FB_Password += key.KeyChar;
						Console.Write ("*");
					} else {
						if (key.Key == ConsoleKey.Backspace && FB_Password.Length > 0) {
							FB_Password = FB_Password.Substring (0, (FB_Password.Length - 1));
							Console.Write ("\b \b");
						}
					}
				} while (key.Key != ConsoleKey.Enter);

				Console.WriteLine ("");
				Console.Write ("Enter Database Name and directory (:x:/data/data/database.fdb): ");
				FB_Database = Console.ReadLine ();

				Console.Write ("Enter Server Port: ");
				FB_Port = Console.ReadLine ();

				FB_Connectionstring = "User ID=" + FB_UserID + ";Password=" + FB_Password + ";Database=" + FB_Datasource + FB_Database + ";DataSource=" + FB_Datasource + ";Port=" + FB_Port + ";Dialect=3;Charset=NONE;Pooling=false;";
			} else {	
				FB_Connectionstring = connectionstring;

			}
		}

		private static void FBTryFilePath (string Path)
		{
			if (Path.Count () < 2) {
				//Tries to write a empty file to the defined path, then removes it
				Console.Write ("Enter a path for the file (C:\\users\\user\\Documents): ");
				FB_PathToFile = Console.ReadLine ();
				FB_PathToFile = FB_PathToFile + "/";
				FB_Path = FB_PathToFile;

				string FB_TryFile=" ";
				string FB_TryPath = "";

				//Name & type for the temporary file
				FB_TryPath = FB_PathToFile + "TEMPWRITEtest.txt";

				//Writing the file
				System.IO.File.WriteAllText (FB_TryPath, FB_TryFile); 

				//Deleting the file
				System.IO.File.Delete(FB_TryPath);

			} else {
				FB_PathToFile = Path + "/";
				FB_Path = Path + "/";
			}

		
		}

		private static void FBFileName (string Name)
		{
			if (Name == "") {
				//Asks the user for the filename & type
				Console.Write ("Enter a name and file type for the file. Example (File.csv): ");
				FB_FileName = Console.ReadLine ();

				//Adds them to the path
				FB_PathToFile = FB_PathToFile + FB_FileName;
			} else {
				FB_FileName = Name;
				FB_PathToFile = FB_PathToFile + Name;
			}

			char Delimiter = '.';
			string[] Filenames = FB_FileName.Split (Delimiter);
			FB_FileFormat = Filenames [1];
		}


		private static void FBCreateMultiFile(List<string> db, string Date,string MultiFile,string Connectionstring)
		{

			char Delimiter = ';';
			char Delimiter2 = '/';
			char Delimiter7 = '=';
			string[] SplitCS = Connectionstring.Split (Delimiter);

			string UserID = SplitCS[0];
			string Password = SplitCS[1];
			string DataSource = SplitCS[3];
			string DataBase = SplitCS[2];
			string dbname = "";

			string[] SplitDataSource = DataBase.Split (Delimiter2);

			for (int z = 0; z < SplitDataSource.Count ()-1; z++) {				
					dbname = dbname + SplitDataSource [z] + "/";
			}

			string[] SplitDataSource2 = dbname.Split (Delimiter7);
			dbname = SplitDataSource2 [1];


			if (MultiFile == "True") {
				
				for (int i = 0; i < db.Count (); i++) {
					
					char Delimiter3 = '/';
					char Delimiter4 = '.';
					FB_FileName = db [i];
					string[] SplitfileName = FB_FileName.Split (Delimiter3);
					FB_FileName = SplitfileName [SplitfileName.Count () - 1];
					SplitfileName = FB_FileName.Split (Delimiter4);
					FB_FileName = SplitfileName [0];
					FB_PathToFile = FB_Path + FB_FileName +"."+ FB_FileFormat;

					DataBase = dbname+ db [i];
					FB_Connectionstring = UserID + ";" + Password + ";" +"DataBase =" + DataBase + ";" + DataSource + ";";
				
					CreateFile (FB_Connectionstring, Date);
					FBMultiFinishingFile ();
					FB_File = "";
				}

				Console.Clear();
				//creates a file from created lists
				Console.WriteLine ("Search complete!");
				Console.WriteLine ("Created a file to: " + FB_Path);
				Console.WriteLine ("");	

				System.Environment.Exit (0);

			} else {
				CreateFile (FB_Connectionstring, Date);
			}

		}
	
		private static void CreateFile (string Connectionstring, string Date)
		{
			
			if (Date == "True") {
				
				string date = DateTime.Today.ToString ("dd-MM-yy", CultureInfo.InvariantCulture);

				char Delimiter = '.';
				string[] Filenames = FB_PathToFile.Split (Delimiter);


				FB_FileName = Filenames [0] + "_" + date + "." + FB_FileFormat;
				FB_PathToFile = FB_FileName;
			}

			if (Connectionstring.Count() > 1) {
				FB_Connectionstring = Connectionstring;
			}

			FbConnection myConnection1 = new FbConnection(FB_Connectionstring);
			FbConnection myConnection2 = new FbConnection(FB_Connectionstring);
			FbConnection myConnection3 = new FbConnection(FB_Connectionstring);

			myConnection1.Open ();
			myConnection2.Open ();
			myConnection3.Open ();

			FbCommand FBTableNames = new FbCommand ("select rdb$relation_name from rdb$relations where " +
				"rdb$view_blr is null and (rdb$system_flag is null or rdb$system_flag = 0)",myConnection1);

			FbDataReader FBreader = FBTableNames.ExecuteReader ();

			while (FBreader.Read ()) {
				FBTABLENAMES.Add(FBreader ["rdb$relation_name"].ToString());
				i++;
			}
			i=0;

			FBreader.Close ();
			//Null "p"
			p = 0;

			// "j" = Databasename list integer
			j=0;
			i=0;

			//adds columns: Database, Table, Column, Datatype, to the file
			FB_File = "Table" + "," + "Column" + "," + "Datatype" + Environment.NewLine;

			//for each found table, adds columns & datatypes for the table
			for (o = 0; o < FBTABLENAMES.Count (); o++) {
				Console.Title = FB_Database;


				//FB command, Chooses the column names based on the table name
				FbCommand FBcmd = new FbCommand  ("select rdb$field_name from rdb$relation_fields where rdb$relation_name='" +FBTABLENAMES[j] +"';",myConnection2);
				FbCommand FBcmd2 = new FbCommand ("select r.rdb$field_name , t.rdb$type_name from rdb$relation_fields r, rdb$types t where r.rdb$relation_name='" +FBTABLENAMES[j] +"' and t.rdb$field_name='RDB$FIELD_TYPE';",myConnection3);

				//Starts another reader "reader2", while it reads, adds column names to a column list and column types to a column list           
				FbDataReader FBreader2 = FBcmd.ExecuteReader ();
				FbDataReader FBreader3 = FBcmd2.ExecuteReader ();

				while (FBreader2.Read ()) {							
					FBCOLUMNNAMES.Add (FBreader2 ["rdb$field_name"].ToString ());
				}

				while (FBreader3.Read()){
					FBCOLUMNTYPES.Add (FBreader3 ["rdb$type_name"].ToString());
				}

				//Combines column names and their types to the File

				for(int g = 0; g < FBCOLUMNNAMES.Count;g++){
					FB_File = FB_File +FBTABLENAMES[j] +","+ FBCOLUMNNAMES [p] + "," + FBCOLUMNTYPES [p] + Environment.NewLine; 
					p++;
				}

				FB_File= FB_File + Environment.NewLine;

				//Writes the current state of going through the tables to console 
				Console.Write ("\r{0}" + "/" + FBTABLENAMES.Count ().ToString (), j);

				FBreader2.Close();
				FBreader3.Close();
				FBCOLUMNNAMES.Clear();
				FBCOLUMNTYPES.Clear();

				p=0;
				j++;

			}
			FBTABLENAMES.Clear ();
			//Clears the console line
			Console.Write("\r              ");

			myConnection1.Close ();
			myConnection2.Close ();
			myConnection3.Close ();
			j = 0;
		}

		private static void FBMultiFinishingFile()
		{
			
			Console.WriteLine (FB_PathToFile);
			System.IO.File.WriteAllText (FB_PathToFile, FB_File);
			FB_FileName = "";
			FB_PathToFile = "";

		
		}

		private static void FBFinishingFile ()
		{
			Console.Clear();
			//creates a file from created lists
			System.IO.File.WriteAllText (FB_PathToFile, FB_File);

			Console.WriteLine ("Search complete!");
			Console.WriteLine ("Created a file to: " + FB_PathToFile);
			Console.WriteLine ("");
			Console.CursorVisible = true;
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write ("Open the file? [y] yes, any other key to exit: ");
			string Valinta = Console.ReadLine ();

			if (Valinta == "y") {
				//Opens the file if user entered [Y]
				Process.Start (FB_PathToFile);
			} 
		}

		//Normal side of Firebird
		private static void FBCleanup ()
		{
			//Clear all the used strings, integers, connections etc.
			FBTABLENAMES.Clear();
			FBCOLUMNNAMES.Clear();
			FBCOLUMNTYPES.Clear();

			i=0;
			p=0;
			j=0;

			FB_Connectionstring = "";
			FB_UserID="";
			FB_Password ="";
			FB_Database = "";
			FB_Datasource = "";
			FB_Port = "";

			FB_PathToFile = "";
			FB_File = "";
			FB_FileName ="";
			System.Environment.Exit (0);
		}

		private static void FBdb ()
		{
			try{
				try{
					FBTryFilePath("");
				}catch (Exception)
				{
					Console.WriteLine("Path not available, check for typos or choose another location");
					Console.WriteLine();
					FB_PathToFile = "";
					FBdb();
				}
				FBFileName("");
				FBConnectionstringChoice();


			}catch (Exception e) {

				FB_Datasource = "";
				FB_Connectionstring = "";
				FB_UserID = "";
				FB_Password = "";
				FB_PathToFile = "";
				FB_FileName = "";
				FB_Port = "";

				Console.Clear ();
				Console.WriteLine ("Error and it's details: "+e);
				Console.WriteLine ("Something went wrong, Try again");
				FBdb ();
			}

			try{
				Console.Clear();
				Console.WriteLine (" ");
				var spinner = new Spinner (8, 4);
				Console.CursorVisible = false;
				spinner.Start ();
				Console.ForegroundColor = ConsoleColor.Green;
				Console.Write ("Fetching data");
				Console.WriteLine("");
				Console.WriteLine("current / Tables");

				CreateFile ("","");

				spinner.Stop ();
				FBFinishingFile ();
				FBCleanup ();	

			}catch (Exception e ) {
				Console.WriteLine (e);
			}
		}


		//Normal side of Firebird
		public static void FireBird ()
		{
			FBdb ();
		}


		//config side of Firebird
		public static void FireBirdConfig(List<string> db,string UsePath, string UseFilename, string UseConnectionString, string Date, string MultiFile)
		{
			FBdbconfig (db,UsePath,UseFilename,UseConnectionString, Date,MultiFile);
		}

		//Config side of Firebird
		private static void FBdbconfig (List<string> db,string UsePath, string UseFilename, string UseConnectionString, string Date, string MultiFile)
		{
			try{
				try{
					//If path name, entered in config file, length is less than 1, asks the user for the path, otherwise uses the path found in config
					//If path in config file is wrong, will make it empty, and ask for it from the user
					if(UsePath.Count() < 1)
					{
						FBTryFilePath("");
					}else{
						FBTryFilePath(UsePath);
					}
				}catch (Exception)
				{
					Console.WriteLine("Path not available, check for typos or choose another location");
					Console.WriteLine();
					FB_PathToFile = "";
					UsePath = "";
					FBdbconfig(db,UsePath,UseFilename,UseConnectionString,Date,MultiFile);
				}
				//If file name, entered in config file, length is less than 1, asks the user for a name for the file, otherwise uses the name found in the config
				if(UseFilename.Count()<1)
				{
					FBFileName("");
				}else{
					FBFileName(UseFilename);
				}

				//If Connection string, entered in config file, length is less than 1, asks the user for a connection string, otherwise uses the CS found in config
				if(UseConnectionString.Count()<1)
				{

					FBConnectionstringChoice();

				}else{
					FB_Connectionstring = UseConnectionString;
				}


			}catch (Exception) {

				FB_Datasource = "";
				FB_Connectionstring = "";
				FB_UserID = "";
				FB_Password = "";
				FB_PathToFile = "";
				FB_FileName = "";
				FB_Port = "";

				Console.Clear ();
				Console.WriteLine ("Something went wrong, Try again");
				UseConnectionString = "";
				FB_Connectionstring = "";
				FBdbconfig (db,UsePath,UseFilename,UseConnectionString,Date,MultiFile);
			}

			try{
				Console.Clear();
				Console.WriteLine (" ");
				var spinner = new Spinner (8, 4);
				Console.CursorVisible = false;
				spinner.Start ();
				Console.ForegroundColor = ConsoleColor.Green;
				Console.Write ("Fetching data");
				Console.WriteLine("");
				Console.WriteLine("current / Tables");

				FBCreateMultiFile(db,Date,MultiFile,UseConnectionString);
				//CreateFile (UseConnectionString,Date);

				spinner.Stop ();
				FBFinishingFile ();
				FBCleanup ();	

			}catch (Exception e ) {
				Console.WriteLine (e);
			}
		}
	}
}