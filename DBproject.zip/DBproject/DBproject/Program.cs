﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;


namespace Application
{	
	class MainClass
	{			
		private static void Main (string[] args)
		{	
			
			//opens up the console at upper left corner, starts the program, kills the program
			Console.SetWindowPosition(0,0);
					
			DatabaseConnection.MainProgram.Program ();

            Console.ReadLine();

		}	
	}	
}