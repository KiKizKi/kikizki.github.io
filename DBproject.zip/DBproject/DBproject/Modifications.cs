﻿using System;

namespace TietokantayhteysFB
{
	public class Modifications
	{
		public Modifications ()
		{
			
			//1. Edited Line 44, Eg: User ID = sa; Password = 1234; Server = 192.168.0.0;.
			//2. Fixed a bug where the program crashed if table name was a SQL keyword eg. DATABASE, SQL.cs Line 250-265.
			//3. Fixed the bug 1: Upon startup, if pressing a key before the program asks the user to choose a DB type, WILL CRASH.
			//4. Upon entering Login details, if they fail, will ask again until theyre correct. ##Doesnt specify which is wrong though##.
			//5. Shows less databases, which the user has no access, still shows some ## ??? ##.
			//6. Now closes the terminal correctly after all events required, But still asks the user to press any key (?).
			//7. If a database has tables named after SQL keywords, all tables are now included in the results,
			//   v.1 did not include them, it crashed on them.



			//8 NEW mechanism for choosing databases: List which you can browse & Autofill a name with TAB
			//9 NEW takes configurations directly from a config.txt file
		   //10 NEW Databases.txt, uses this as a list for databasenames, if set to TRUE in config file

		}
	}
}

