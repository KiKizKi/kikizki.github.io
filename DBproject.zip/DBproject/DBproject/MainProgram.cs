﻿using System;

namespace DatabaseConnection
{
	

	public class MainProgram
	{		
		//Writes 2 empty lines, sets color to white, shows the cursor
		private static void startupConsole ()
		{
			try{
			Console.WriteLine ("");
			Console.WriteLine ("");
			Console.ForegroundColor = ConsoleColor.White;
			Console.CursorVisible =true;
			}catch (Exception e)
			{
				Console.WriteLine ("");
				Console.WriteLine ("Error details: " + e);	
			}
		}

		//Starts by calling Startuptext, and Startupconsole mentioned above, then checks to use config
		private static void Connections()
		{
		try{
				DatabaseConnection.StartUPtext.Startup();
				startupConsole();

				DatabaseConnection.Config.USECONFIG();

			}catch (Exception e)
			{
				Console.WriteLine ("");
				Console.WriteLine ("Error details: " + e);	
			}
		}


		public static void Program ()
		{
			Connections ();

		}
	}
}