﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;
using System.Globalization;

namespace DatabaseConnection
{
	public class DBTYPE
	{
		//gets the DB type from user. 1 = SQL, 2 = Firebird, does not allow any other input
		private static void DB()
		{		
			string DBtype = "";				

				ConsoleKeyInfo inputKey;

				Console.Write ("Type [1] for a SQL DB or [2] for Firebird DB:  ");

				do {				
					inputKey = Console.ReadKey (true);

					if (inputKey.Key == ConsoleKey.D1) {	
						Console.Write ("\b");
						Console.Write (inputKey.KeyChar);
						DBtype = "1";
					}
					if (inputKey.Key == ConsoleKey.D2) {	
						Console.Write ("\b");
						Console.Write (inputKey.KeyChar);
						DBtype = "2";
					}					
				} while (inputKey.Key != ConsoleKey.Enter);

				Console.WriteLine ();

				//Firebird part of the program
				if (DBtype == "2") {
					try {
						DatabaseConnection.FireBirdDB.FireBird ();
					} catch (Exception e) {
						Console.WriteLine (e);
					}
				}

				//SQL part of the program
				if (DBtype == "1") {
					try {
						DatabaseConnection.SQLDB.SQL ();
					} catch (Exception e) {
						Console.WriteLine (e);
					}

				} else {

					Console.WriteLine ("You did not specify the Database type");
					Console.WriteLine ("The program will now exit");
				}
			}	

			public static void DBSelection ()
			{				
				DB ();	
			}

		}



			//Config side. otherwise similar
				public class DBTYPEconfig
				{

				//Proceeds with the list of DB's, Choice OF DBtype, Path, File name, Connectionstring, And choice of using databases
		private static void DB(List<string> db,int Choice, string UsePath, string UseFilename, string UseConnectionString, string UseDatabasenames, string MultiFile, string Dates)
				{		
					//Firebird part of the program
					if (Choice == 2) {
						try {
							
					DatabaseConnection.FireBirdDB.FireBirdConfig (db, UsePath, UseFilename, UseConnectionString, Dates, MultiFile);
						} catch (Exception e) {
							Console.WriteLine (e);
						}
					}

					//SQL part of the program
					if (Choice == 1) {
						try {
					DatabaseConnection.SQLDB.SQLconfig (db,UsePath,UseFilename,UseConnectionString,UseDatabasenames, MultiFile, Dates);
						} catch (Exception e) {
							Console.WriteLine (e);
						}

					} else {

						Console.WriteLine ("You did not specify the Database type");
						Console.WriteLine ("The program will now exit");
					}
				}

				//Uses method DB, with the list of DB's, Choice OF DBtype, Path, File name, Connectionstring, And choice of using databases
		public static void DBSelectionconfig (List<string> db, int Choice, string UsePath, string UseFilename, string UseConnectionString, string UseDatabasenames, string MultiFile, string Dates)
				{			
			DB (db,Choice,UsePath,UseFilename,UseConnectionString,UseDatabasenames,MultiFile,Dates);

				}
		}
}