﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Specialized;
using System.IO;


namespace DatabaseConnection
{
    public class Config
    {
        //Strings, ints, list
        static string directory = AppDomain.CurrentDomain.BaseDirectory;
        static string UseConfig = "";
        static string configSQL = "";
        static string configPath = "";
        static string configFilename = "";
        static string configUseConnectionString = "";
        static string configConnectionString = "";
        static string configDatabases = "";
        static string configAddDates = "";
        static string configMultiFile = "";

        static List<string> configDBS = new List<string>();

        static List<string> found = new List<string>();
        static List<string> foundNFormatted = new List<string>();


        //Type 1 = SQL
        //Type 2 = Firebird
        static int type = 0;

        //Searches for a a configfile and gets the data from it
        private static void CONFIG()
        {

            
            
            					
            
            
            
            //
            if (foundNFormatted[0] == "TRUE")
            {
                UseConfig = "TRUE";
            }
            if (foundNFormatted[0] == "FALSE")
            {
                UseConfig = "FALSE";
            }
            if (foundNFormatted[0] != "TRUE" && foundNFormatted[0] != "FALSE")
            {
                UseConfig = "FAILED";
            }

            //				configSQL 		= 
            if (foundNFormatted[1] == "TRUE")
            {
                configSQL = "TRUE";
            }
            if (foundNFormatted[1] == "FALSE")
            {
                configSQL = "FALSE";
            }
            if (foundNFormatted[1] != "TRUE" && foundNFormatted[1] != "FALSE")
            {
                configSQL = "FAILED";
            }

            //				configPath 		=             
                configPath = foundNFormatted[2];

            //				configFilename 	= 
                configFilename = foundNFormatted[3];

            //				configDatabases = 
            if (foundNFormatted[5] == "TRUE")
            {
                configDatabases = "TRUE";
            }
            if (foundNFormatted[5] == "FALSE")
            {
                configDatabases = "FALSE";
            }
            if (foundNFormatted[5] != "TRUE" && foundNFormatted[4] != "FALSE")
            {
                configDatabases = "FAILED";
            }

            //				configMultiFile = 
            if (foundNFormatted[6] == "TRUE")
            {
                configMultiFile = "TRUE";
            }
            if (foundNFormatted[6] == "FALSE")
            {
                configMultiFile = "FALSE";
            }
            if (foundNFormatted[6] != "TRUE" && foundNFormatted[5] != "FALSE")
            {
                configMultiFile = "FAILED";
            }

            //				configAddDates 	= 
            if (foundNFormatted[7] == "TRUE")
            {
                configAddDates = "TRUE";
            }
            if (foundNFormatted[7] == "FALSE")
            {
                configAddDates = "FALSE";
            }
            if (foundNFormatted[7] != "TRUE" && foundNFormatted[6] != "FALSE")
            {
                configAddDates = "FAILED";
            }
        }

        private static void METHOD()
        {

            char Delimiter = ' ';
            char Delimiter2 = '=';
            string configfile = directory + "/" + "Config.txt";

            string line;
            using (StreamReader file = new StreamReader(configfile))
            {

                while ((line = file.ReadLine()) != null)
                {
                    if (line.Contains("SQL="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }

                    }

                    if (line.Contains("UseConfig="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }

                    }

                    if (line.Contains("Path="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }

                    }

                    if (line.Contains("Filename="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }


                    }
                   

                    if (line.Contains("UsePremadeConnectionString="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }

                    }

                    if (line.Contains("Databases="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }


                    }

                    if (line.Contains("MultipleFiles="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }


                    }

                    if (line.Contains("AddDates="))
                    {
                        try
                        {
                            line = line.ToUpper();
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);                     
                            string[] b = a[1].Split(Delimiter);

                            if (b.Length == 1)
                            {
                                foundNFormatted.Add(b[0]);
                            }
                            else
                            {
                                foundNFormatted.Add(b[1]);
                            }
                        }
                        catch (Exception)
                        {
                        }


                    }
                }
            }
        }

        //Chooses which side to use, SQL or Firebird
        private static void cfgDBTYPE()
        {
            if (configSQL == "TRUE")
            {
                type = 1;
            }

            if (configSQL == "FALSE")
            {
                type = 2;
            }

            if (type != 1 && type != 2)
            {
                Console.WriteLine("The Database type, is not set correctly");
                Console.ReadLine();
            }
        }



        //Gets the path from the config file. If no file was entered, uses empty, and asks for it later
        private static void cfgPATH()
        {
            if (configPath.Count() < 8)
            {
                configPath = "";
            }
            else
            {
                configPath = configPath.Substring(7, configPath.Count() - 7);
            }
        }

        //Gets the name from the config file. If no name was enterd, uses empty, and asks for it later
        private static void cfgFILENAME()
        {
            if (configFilename.Count() < 12)
            {
                configFilename = "";
            }
            else
            {
                configFilename = configFilename.Substring(11, configFilename.Count() - 11);
            }
        }

        //Checks whether or not to use the connection string
        private static void cfgUSECONNECTIONSTRING()
        {
            

            if (configUseConnectionString == "USEPREMADECONNECTIONSTRING = TRUE")
            {
                cfgCONNECTIONSTRING(configUseConnectionString);

            }
            else
            {
                configConnectionString = "";
                cfgCONNECTIONSTRING("");
            }
        }

        //Gets the connection string from the config file. If no string was entered, uses empty, and asks for it later
        private static void cfgCONNECTIONSTRING(string CS)
        {
            char Delimiter = ' ';
            char Delimiter2 = '=';
            string configfile = directory + "/" + "Config.txt";

            string line;
            using (StreamReader file = new StreamReader(configfile))
            {

                while ((line = file.ReadLine()) != null)
                {

                    if (line.Contains("Connectionstring="))
                    {
                        try
                        {
                            found.Add(line);
                            string[] a = line.Split(Delimiter2);

                            List<string> testilista = new List<string>();
                            foreach (string testi in a)
                            {
                                testilista.Add(testi);
                            }
                            testilista.RemoveAt(0);

                            for (int i = 0; i < testilista.Count; i++)
                            {
                                configConnectionString = configConnectionString + "=" + testilista[i];
                            }

                            configConnectionString = configConnectionString.Substring(1, configConnectionString.Length - 1);


                            Console.WriteLine();
                        }
                        catch (Exception)
                        {
                        }
                    }
                }
            }
        }
        //Checks whether or not to use Databases from the Databases.txt File
        private static void cfgDATABASES()
        {
            if (configDatabases == "DATABASES = *ALL*")
            {

                SqlConnection AllDbs = new SqlConnection(configConnectionString);
                AllDbs.Open();

                SqlCommand DBNames = new SqlCommand("SELECT name from sys.sysdatabases WHERE HAS_DBACCESS(name) = 1", AllDbs);
                SqlDataReader DBreader = DBNames.ExecuteReader();
                while (DBreader.Read())
                {
                    configDBS.Add(DBreader["name"].ToString());
                }

                DBreader.Close();
                AllDbs.Close();
            }


            if (configDatabases == "DATABASES = TRUE")
            {
                try
                {
                    string dbfile = directory + "/" + "Databases.txt";
                    string[] DBS = System.IO.File.ReadAllLines(dbfile);

                    foreach (string db in DBS)
                    {
                        configDBS.Add(db.ToString());
                    }
                }
                catch (Exception)
                {
                    System.IO.File.WriteAllText(directory + "/Databases.txt", "");
                    Console.WriteLine("Could not find Databases.txt File. Created one at: " + directory);
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    System.Environment.Exit(0);
                }
            }
        }

        //If the program couldn't find a config file, this creates a new one, at the directory of the program
        private static void Configfile()
        {
            string cfgFile = "";

            cfgFile = "﻿config file, Edit each Line after the character \"=\",REMEMBER NOT TO add a space between the question and the \"=\" \n" +
                        "\n" +
                      "//true=Uses this Config file\n" +
                      "//false=doesn't\n" +
                      "UseConfig=false\n" +
                      "\n" +
                      "//true=uses SQL\n" +
                      "//false=uses Firebird\n" +
                      "SQL=true\n" +
                      "\n" +
                      "\n" +
                      "//Path for the file [Default: /home/[Your_Username]/Documents]\n" +
                      "//Name for the file\n" +
                      "Path=/home/user/Desktop\n" +
                      "Filename=File.csv\n" +
                      "\n" +
                      "\n" +
                      "//true = uses premade connection defined below [SQL : \"User ID=sa;Password=admin;Server=192.168.0.0;\"]\n" +
                      "//false = asks required information on startup [FBD : \"User ID=sysdba;Password=admin;Database=192.168.0.0:X:/Folder/DBname.fdb;DataSource=192.168.0.0;\"]\n" +
                      "UsePremadeConnectionString = true\n" +
                      "Connectionstring=\"User ID = sa;Password = admin; Server = 192.168.0.0;\"\n" +
                      "\n" +
                      "\n" +
                      "//true= uses databasenames found from the \"Databases.txt\" file\n" +
                      "//false= asks names on startup\n" +
                      "//*ALL* Chooses All found Databases from the connection\n" +
                      "Databases=false\n" +
                      "\n" +
                      "// ^ ! Each database on a new line ! ^\n" +
                      "\n" +
                      "\n" +
                      "//true Creates a different file for every database *Renames the file as the database. Regardless of option above\n" +
                      "//false Creates 1 big file, with all databases in it\n" +
                      "MultipleFiles=true\n" +
                      "\n" +
                      "\n" +
                      "//true Adds the current system date (DD/MM/YY), to the filename, eg. (DB_04-05-17)\n" +
                      "//false Doesn't\n" +
                      "AddDates=true\n" +
                      "\n" +
                      "//IF you've lost your [Databases.txt] file, Just manually create one at the same directory where THIS config.txt is in\n" +
                      "//Name it exactly: Databases.txt";

            System.IO.File.WriteAllText(directory + "/Config.txt", cfgFile);
            Console.WriteLine("Couldn't find a config file, created a new one at: " + directory);
            Console.WriteLine("Please restart the program");
        }

        private static void cfgUSEMULTIFILE()
        {
            if (configMultiFile == "MULTIPLEFILES = TRUE")
            {
                configMultiFile = "True";
            }
            else
            {
                configMultiFile = "";
            }
        }

        private static void cfgUSEDATES()
        {
            if (configAddDates == "ADDDATES = TRUE")
            {
                configAddDates = "True";
            }
            else
            {
                configAddDates = "";
            }
        }

        //chekcs whether or not to use the config, or skip it
        public static void USECONFIG()
        {            
            METHOD();
            CONFIG();

            if (UseConfig == "FALSE")
            {
                DatabaseConnection.DBTYPE.DBSelection();
            }
            if (UseConfig == "TRUE")
            {
                Start();
            }
            if (UseConfig != "TRUE" && UseConfig != "FALSE")
            {
                //Do something to tell user their choice is incorrect
            }
        }


        //Calls all the methods in this class, empties values afterwards
        private static void Start()
        {
            //Go through every option
            CONFIG();
            cfgDBTYPE();
            cfgUSECONNECTIONSTRING();
            cfgPATH();
            cfgFILENAME();
            cfgDATABASES();
            cfgUSEMULTIFILE();
            cfgUSEDATES();
            DatabaseConnection.DBTYPEconfig.DBSelectionconfig(configDBS, type, configPath, configFilename, configConnectionString, configDatabases, configMultiFile, configAddDates);

            //Null every option
            directory = "";
            UseConfig = "";
            configSQL = "";
            configPath = "";
            configFilename = "";
            configUseConnectionString = "";
            configConnectionString = "";
            configDatabases = "";
            configAddDates = "";
            configMultiFile = "";
            type = 0;
            configDBS.Clear();
        }
    }
}
